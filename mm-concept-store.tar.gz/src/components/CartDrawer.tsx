import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Trash2,
  ShoppingBag,
  Send,
  Copy,
  Check,
  Sparkles,
  MapPin,
  Store,
  AlertCircle,
  Search,
  Loader2,
  Camera,
  Upload,
  Image as ImageIcon,
  FileCheck,
  Eye,
  Truck,
  User,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, CustomerOrderData, DeliveryType, StoreSettings, Order, CustomerUser } from '../types';
import { formatCurrency, generateWhatsAppOrderUrl, copyToClipboard } from '../lib/utils';
import { compressImage } from '../lib/imageCompressor';
import { uploadProductImage } from '../lib/supabase';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQuantity: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  onCreateOrder: (order: Order) => void;
  settings: StoreSettings;
  currentUser?: CustomerUser | null;
  onOpenCustomerAuth?: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onCreateOrder,
  settings,
  currentUser,
  onOpenCustomerAuth,
}) => {
  const [customer, setCustomer] = useState<CustomerOrderData>({
    name: '',
    phone: '',
    deliveryType: 'delivery', // default to delivery so address is emphasized
    cep: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
    notes: '',
  });

  // Pre-fill customer data when logged in
  useEffect(() => {
    if (currentUser) {
      setCustomer((prev) => ({
        ...prev,
        name: prev.name || currentUser.name || '',
        phone: prev.phone || currentUser.phone || '',
        email: currentUser.email,
        customerId: currentUser.id,
        cep: prev.cep || currentUser.cep || '',
        street: prev.street || currentUser.street || '',
        number: prev.number || currentUser.number || '',
        complement: prev.complement || currentUser.complement || '',
        neighborhood: prev.neighborhood || currentUser.neighborhood || '',
        city: prev.city || currentUser.city || '',
        state: prev.state || currentUser.state || '',
      }));
    }
  }, [currentUser, isOpen]);

  const [copiedPix, setCopiedPix] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [cepNotice, setCepNotice] = useState<string | null>(null);

  // PIX Receipt states
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptBlob, setReceiptBlob] = useState<Blob | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [receiptFileName, setReceiptFileName] = useState<string>('');
  const [isProcessingReceipt, setIsProcessingReceipt] = useState(false);
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [showReceiptZoom, setShowReceiptZoom] = useState(false);
  const receiptInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCopyPix = async () => {
    const success = await copyToClipboard(settings.pixKey);
    if (success) {
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 2500);
    }
  };

  const handleCepSearch = async (rawCep: string) => {
    const cleanCep = rawCep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    setIsSearchingCep(true);
    setCepNotice(null);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await res.json();
      if (data.erro) {
        setCepNotice('CEP não encontrado. Preencha o endereço manualmente.');
      } else {
        setCustomer((prev) => ({
          ...prev,
          street: data.logradouro || prev.street,
          neighborhood: data.bairro || prev.neighborhood,
          city: data.localidade || prev.city,
          state: data.uf || prev.state,
          complement: data.complemento || prev.complement,
        }));
        setCepNotice('✅ Endereço preenchido automaticamente pelo CEP!');
        setTimeout(() => setCepNotice(null), 3500);
      }
    } catch {
      setCepNotice('Não foi possível consultar o CEP agora. Preencha manualmente.');
    } finally {
      setIsSearchingCep(false);
    }
  };

  const handleReceiptFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Por favor, selecione um arquivo de imagem válido (JPG, PNG, HEIC, etc.) para o comprovante.');
      return;
    }

    setFormError(null);
    setIsProcessingReceipt(true);

    try {
      // Compress smartphone photo/screenshot (max 1200px, fast, lightweight ~150KB)
      const compressed = await compressImage(file, 1200, 1200, 0.82);
      setReceiptFile(file);
      setReceiptBlob(compressed.blob);
      setReceiptPreview(compressed.dataUrl);
      setReceiptFileName(file.name);
    } catch (err) {
      console.warn('Compress fallback to direct data URL:', err);
      const reader = new FileReader();
      reader.onload = (event) => {
        setReceiptPreview(event.target?.result as string);
        setReceiptFile(file);
        setReceiptBlob(file);
        setReceiptFileName(file.name);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsProcessingReceipt(false);
      if (receiptInputRef.current) {
        receiptInputRef.current.value = '';
      }
    }
  };

  const handleRemoveReceipt = () => {
    setReceiptFile(null);
    setReceiptBlob(null);
    setReceiptPreview(null);
    setReceiptFileName('');
    if (receiptInputRef.current) {
      receiptInputRef.current.value = '';
    }
  };

  const handleCheckout = async () => {
    setFormError(null);

    // Basic validations
    if (!customer.name.trim()) {
      setFormError('Por favor, informe o seu Nome Completo para identificação do pedido.');
      return;
    }

    if (!customer.phone.trim() || customer.phone.replace(/\D/g, '').length < 8) {
      setFormError('Por favor, informe um WhatsApp de contato válido com DDD.');
      return;
    }

    if (customer.deliveryType === 'delivery') {
      if (!customer.street?.trim()) {
        setFormError('Por favor, informe a Rua / Avenida do endereço de entrega.');
        return;
      }
      if (!customer.number?.trim()) {
        setFormError('Por favor, informe o Número da residência (ou S/N).');
        return;
      }
      if (!customer.neighborhood?.trim()) {
        setFormError('Por favor, informe o Bairro de entrega.');
        return;
      }
      if (!customer.city?.trim()) {
        setFormError('Por favor, informe a Cidade de entrega.');
        return;
      }
    }

    // MANDATORY RECEIPT VALIDATION: Must attach receipt to proceed to WhatsApp
    if (!receiptPreview) {
      setFormError('⚠️ É obrigatório anexar o comprovante do PIX para liberar o envio do seu pedido no WhatsApp!');
      const el = document.getElementById('pix-receipt-section');
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    setIsSubmittingOrder(true);

    try {
      // Generate unique order ID
      const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
      const orderId = `MM-${Date.now().toString().slice(-4)}${randomSuffix}`;

      // Upload receipt to Supabase Storage if available
      let uploadedReceiptUrl: string | undefined = undefined;
      if (receiptBlob) {
        try {
          const remoteUrl = await uploadProductImage(receiptBlob, `comprovante_${orderId}.jpg`);
          if (remoteUrl) {
            uploadedReceiptUrl = remoteUrl;
          }
        } catch (err) {
          console.warn('Notice: upload to Supabase storage skipped, using base64 preview:', err);
        }
      }

      const finalReceiptImage = uploadedReceiptUrl || receiptPreview;

      // Build Order object
      const newOrder: Order = {
        id: orderId,
        customerName: customer.name.trim(),
        customerPhone: customer.phone.trim(),
        customerEmail: currentUser?.email || customer.email || '',
        customerId: currentUser?.id || customer.customerId || '',
        deliveryType: customer.deliveryType,
        cep: customer.cep?.trim() || '',
        street: customer.street?.trim() || '',
        number: customer.number?.trim() || '',
        complement: customer.complement?.trim() || '',
        neighborhood: customer.neighborhood?.trim() || '',
        city: customer.city?.trim() || '',
        state: customer.state?.trim() || '',
        notes: customer.notes?.trim() || '',
        items: items.map((item) => ({
          productId: item.product.id,
          productName: item.product.name,
          productImage: item.product.images?.[0] || '',
          size: item.selectedSize,
          color: item.selectedColor,
          price: item.product.price,
          quantity: item.quantity,
        })),
        subtotal,
        total: subtotal,
        paymentMethod: 'pix',
        status: 'pending',
        stockDeducted: false,
        receiptImage: finalReceiptImage,
        createdAt: new Date().toISOString(),
      };

      // Save order in store state / Supabase
      onCreateOrder(newOrder);

      // Trigger celebration confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#c5a059', '#1c1917', '#e8decd', '#ffffff'],
        });
      } catch {
        // safe fallback
      }

      // Generate WhatsApp URL with order ID and receipt notice
      const whatsappUrl = generateWhatsAppOrderUrl(items, customer, settings, orderId, uploadedReceiptUrl);

      // Open WhatsApp
      window.open(whatsappUrl, '_blank');

      // Clear cart so client has a clean state
      handleRemoveReceipt();
      onClearCart();
      onClose();
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  return (
    <div
      id="cart-drawer-overlay"
      className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm transition-opacity"
      onClick={onClose}
    >
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div
          id="cart-drawer-container"
          className="w-screen max-w-md bg-[#faf8f5] shadow-2xl flex flex-col border-l border-[#e8dfd2]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-4 sm:p-5 bg-white border-b border-[#e8dfd2] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#8e6e34]" />
              <h2 className="font-serif text-xl font-medium text-[#1c1917]">
                Sua Sacola
              </h2>
              <span className="text-xs font-semibold bg-[#f0ebe1] text-[#786e64] px-2 py-0.5 rounded-full">
                {items.reduce((sum, item) => sum + item.quantity, 0)} itens
              </span>
            </div>

            <button
              type="button"
              id="close-cart-drawer-button"
              onClick={onClose}
              className="p-1.5 rounded-full text-[#786e64] hover:text-[#1c1917] hover:bg-[#f0ebe1] transition-colors"
              aria-label="Fechar sacola"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Content */}
          {items.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#f0ebe1] flex items-center justify-center text-[#8e6e34]">
                <ShoppingBag className="w-8 h-8 opacity-60" />
              </div>
              <div className="space-y-1">
                <h3 className="font-serif text-lg font-medium text-[#1c1917]">
                  Sua sacola está vazia
                </h3>
                <p className="text-xs text-[#786e64] max-w-xs leading-relaxed">
                  Explore nossas coleções exclusivas de linho e alfaiataria e monte seus looks favoritos.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="mt-2 px-6 py-2.5 bg-[#1c1917] text-white text-xs font-semibold uppercase tracking-wider rounded-full hover:bg-[#322c29] transition-colors"
              >
                Explorar Catálogo
              </button>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
              {/* Product Items List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-[#8c8278] uppercase tracking-wider">
                  <span>Peças Selecionadas</span>
                  <button
                    onClick={onClearCart}
                    className="hover:text-red-700 transition-colors"
                  >
                    Esvaziar
                  </button>
                </div>

                <div className="divide-y divide-[#e8e2d8] bg-white rounded-xl border border-[#e8e2d8] overflow-hidden">
                  {items.map((item) => (
                    <div key={item.id} className="p-3 sm:p-4 flex gap-3 items-center">
                      <img
                        src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=400&q=80'}
                        alt={item.product.name}
                        className="w-16 h-20 object-cover rounded-lg bg-[#f5efe6] shrink-0"
                      />

                      <div className="flex-1 min-w-0 space-y-1">
                        <h4 className="text-xs font-semibold text-[#1c1917] truncate">
                          {item.product.name}
                        </h4>
                        
                        <div className="flex flex-wrap gap-1 text-[11px] text-[#786e64]">
                          <span className="bg-[#f5efe6] px-1.5 py-0.5 rounded border border-[#e8e2d8]">
                            Tam: <strong>{item.selectedSize}</strong>
                          </span>
                          {item.selectedColor && (
                            <span className="bg-[#f5efe6] px-1.5 py-0.5 rounded border border-[#e8e2d8]">
                              {item.selectedColor}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-xs font-bold text-[#1c1917]">
                            {formatCurrency(item.product.price * item.quantity)}
                          </span>

                          <div className="flex items-center gap-2">
                            {/* Stepper */}
                            <div className="inline-flex items-center rounded border border-[#d5cbbe] bg-[#faf8f5]">
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                                className="w-6 h-6 flex items-center justify-center text-xs text-[#5c544c] hover:bg-[#f0ebe1]"
                              >
                                -
                              </button>
                              <span className="w-6 text-center text-xs font-semibold text-[#1c1917]">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                                className="w-6 h-6 flex items-center justify-center text-xs text-[#5c544c] hover:bg-[#f0ebe1]"
                              >
                                +
                              </button>
                            </div>

                            {/* Remove button */}
                            <button
                              type="button"
                              onClick={() => onRemoveItem(item.id)}
                              className="text-stone-400 hover:text-red-600 transition-colors p-1"
                              title="Remover peça"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Customer Details Form */}
              <div className="bg-white p-4 rounded-xl border border-[#e8e2d8] space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#1c1917]">
                  <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span>Seus Dados Para o Atendimento</span>
                </div>

                {/* Customer Account Status / Prompt */}
                {currentUser ? (
                  <div className="p-3 bg-[#f5ede2] border border-[#dfcfb9] rounded-xl flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 rounded-full bg-[#c5a059]/20 text-[#8e6e34] flex items-center justify-center shrink-0">
                        <User className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-semibold text-[#1c1917] truncate">
                          Olá, {currentUser.name}
                        </div>
                        <div className="text-[10px] text-stone-500 truncate">{currentUser.email}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomer({
                          name: currentUser.name || '',
                          phone: currentUser.phone || '',
                          deliveryType: 'delivery',
                          email: currentUser.email,
                          customerId: currentUser.id,
                          cep: currentUser.cep || '',
                          street: currentUser.street || '',
                          number: currentUser.number || '',
                          complement: currentUser.complement || '',
                          neighborhood: currentUser.neighborhood || '',
                          city: currentUser.city || '',
                          state: currentUser.state || '',
                          notes: customer.notes || '',
                        });
                      }}
                      className="px-2.5 py-1 text-[11px] font-semibold text-[#866327] bg-white border border-[#dfcfb9] rounded-lg hover:bg-[#faf7f2] transition-colors shrink-0"
                    >
                      Preencher Salvos
                    </button>
                  </div>
                ) : (
                  <div className="p-3 bg-[#faf7f2] border border-[#e8dfd2] rounded-xl flex items-center justify-between gap-2 text-xs">
                    <div className="text-stone-600">
                      <span>Já tem conta? </span>
                      <button
                        type="button"
                        onClick={onOpenCustomerAuth}
                        className="font-semibold text-[#936f33] hover:underline"
                      >
                        Entre ou Cadastre-se
                      </button>
                    </div>
                  </div>
                )}

                {formError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{formError}</span>
                  </div>
                )}

                <div className="space-y-2.5">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#5c544c] mb-1">
                      Seu Nome Completo *
                    </label>
                    <input
                      id="cart-customer-name-input"
                      type="text"
                      placeholder="Ex: Beatriz Albuquerque"
                      value={customer.name}
                      onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                      className="w-full text-xs p-2.5 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#5c544c] mb-1">
                      Seu WhatsApp (DDD + Número) *
                    </label>
                    <input
                      id="cart-customer-phone-input"
                      type="tel"
                      placeholder="Ex: (11) 98765-4321"
                      value={customer.phone}
                      onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                      className="w-full text-xs p-2.5 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                    />
                  </div>

                  {/* Envio da Loja 100% Online */}
                  <div className="p-3 bg-[#faf7f2] border border-[#e8dfd2] rounded-xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#f0e8dc] flex items-center justify-center text-[#8e6e34] shrink-0">
                      <Truck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-[#1c1917]">
                        Boutique 100% Online • Envio para Todo o Brasil
                      </div>
                      <div className="text-[10px] text-[#786e64]">
                        Entregamos no seu endereço via Correios ou Transportadora
                      </div>
                    </div>
                  </div>

                  {/* Address fields */}
                  <div className="pt-2 border-t border-[#f0ebe3] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#1c1917] uppercase tracking-wider flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-[#8e6e34]" />
                        Endereço de Entrega
                      </span>
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        Obrigatório
                      </span>
                    </div>

                      {/* CEP with auto-fill */}
                      <div>
                        <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">
                          CEP (busca automática de rua e bairro)
                        </label>
                        <div className="relative flex gap-1.5">
                          <input
                            type="text"
                            maxLength={9}
                            placeholder="Ex: 01310-100"
                            value={customer.cep || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setCustomer({ ...customer, cep: val });
                              if (val.replace(/\D/g, '').length === 8) {
                                handleCepSearch(val);
                              }
                            }}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => customer.cep && handleCepSearch(customer.cep)}
                            disabled={isSearchingCep}
                            className="px-3 py-2 bg-[#1c1917] text-white text-xs font-medium rounded-lg hover:bg-[#332e29] transition-colors shrink-0 flex items-center gap-1 disabled:opacity-50"
                            title="Buscar CEP"
                          >
                            {isSearchingCep ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Search className="w-3.5 h-3.5" />
                            )}
                            <span className="hidden sm:inline">Buscar</span>
                          </button>
                        </div>
                        {cepNotice && (
                          <p className="text-[10px] text-[#8e6e34] font-medium mt-1">{cepNotice}</p>
                        )}
                      </div>

                      {/* Rua e Número */}
                      <div className="grid grid-cols-3 gap-2">
                        <div className="col-span-2">
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">Rua / Avenida *</label>
                          <input
                            type="text"
                            placeholder="Ex: Av. Paulista"
                            value={customer.street || ''}
                            onChange={(e) => setCustomer({ ...customer, street: e.target.value })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">Número *</label>
                          <input
                            type="text"
                            placeholder="Ex: 1578"
                            value={customer.number || ''}
                            onChange={(e) => setCustomer({ ...customer, number: e.target.value })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Complemento e Bairro */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">Complemento</label>
                          <input
                            type="text"
                            placeholder="Apto 42, Bloco B..."
                            value={customer.complement || ''}
                            onChange={(e) => setCustomer({ ...customer, complement: e.target.value })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">Bairro *</label>
                          <input
                            type="text"
                            placeholder="Ex: Bela Vista"
                            value={customer.neighborhood || ''}
                            onChange={(e) => setCustomer({ ...customer, neighborhood: e.target.value })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Cidade e Estado */}
                      <div className="grid grid-cols-3 gap-2">
                        <div className="col-span-2">
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">Cidade *</label>
                          <input
                            type="text"
                            placeholder="Ex: São Paulo"
                            value={customer.city || ''}
                            onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-[#5c544c] mb-0.5">UF (Estado) *</label>
                          <input
                            type="text"
                            maxLength={2}
                            placeholder="SP"
                            value={customer.state || ''}
                            onChange={(e) => setCustomer({ ...customer, state: e.target.value.toUpperCase() })}
                            className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg uppercase focus:bg-white focus:border-[#8e6e34] focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#5c544c] mb-1">
                      Observações / Dúvidas (Opcional)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Ex: Gostaria de confirmar a data de entrega ou medidas..."
                      value={customer.notes || ''}
                      onChange={(e) => setCustomer({ ...customer, notes: e.target.value })}
                      className="w-full text-xs p-2 bg-[#faf8f5] border border-[#d5cbbe] rounded-lg focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* PIX Payment Card */}
              <div className="bg-[#f4efe5] p-4 rounded-xl border border-[#dfd2c0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                    <span className="text-xs font-bold uppercase tracking-wider text-[#1c1917]">
                      Pagamento 100% via PIX
                    </span>
                  </div>
                  <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                    Sem Taxas
                  </span>
                </div>

                <p className="text-[11px] text-[#5c544c] leading-snug">
                  Aceitamos exclusivamente PIX para agilizar o envio imediato da sua peça. Você pode copiar a chave abaixo agora ou receber pelo WhatsApp:
                </p>

                {/* Pix Key Box */}
                <div className="bg-white p-2.5 rounded-lg border border-[#dcd1bf] flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] uppercase text-[#8c8278] font-semibold">
                      Chave PIX ({settings.pixKeyType.toUpperCase()}):
                    </div>
                    <div className="text-xs font-mono font-bold text-[#1c1917] truncate select-all">
                      {settings.pixKey}
                    </div>
                    <div className="text-[10px] text-[#786e64] truncate">
                      Favorecido: {settings.pixBeneficiary}
                    </div>
                  </div>

                  <button
                    type="button"
                    id="copy-pix-key-button"
                    onClick={handleCopyPix}
                    className={`px-3 py-2 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 shrink-0 shadow-sm ${
                      copiedPix
                        ? 'bg-emerald-700 text-white'
                        : 'bg-[#1c1917] text-white hover:bg-[#322c29]'
                    }`}
                  >
                    {copiedPix ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Copiada!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-[#e6c687]" />
                        Copiar Chave
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* PIX Receipt Upload Card (MANDATORY) */}
              <div
                id="pix-receipt-section"
                className={`p-4 rounded-xl border transition-all space-y-3 ${
                  !receiptPreview
                    ? 'bg-amber-50/80 border-amber-300 shadow-xs'
                    : 'bg-emerald-50/80 border-emerald-300 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <FileCheck className={`w-4 h-4 ${!receiptPreview ? 'text-amber-700' : 'text-emerald-700'}`} />
                      <span className="text-xs font-bold uppercase tracking-wider text-[#1c1917]">
                        Comprovante do PIX
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          !receiptPreview
                            ? 'bg-amber-200 text-amber-900 border border-amber-300'
                            : 'bg-emerald-200 text-emerald-900 border border-emerald-300'
                        }`}
                      >
                        {!receiptPreview ? 'Obrigatório' : 'Anexado ✓'}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#5c544c] leading-snug">
                      <strong>Aviso importante:</strong> Para que seu pedido seja liberado e despachado pela Mariane, é obrigatório anexar a foto ou print do comprovante do pagamento PIX.
                    </p>
                  </div>
                </div>

                {/* Hidden File Input */}
                <input
                  ref={receiptInputRef}
                  id="receipt-file-input"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleReceiptFileChange}
                />

                {!receiptPreview ? (
                  <div
                    onClick={() => receiptInputRef.current?.click()}
                    className="cursor-pointer border-2 border-dashed border-amber-300 hover:border-amber-500 bg-white/90 hover:bg-amber-50 rounded-xl p-4 text-center transition-all group flex flex-col items-center justify-center gap-2.5"
                  >
                    <div className="w-12 h-12 rounded-full bg-amber-100/90 text-amber-800 flex items-center justify-center group-hover:scale-110 transition-transform shadow-xs">
                      <Camera className="w-6 h-6" />
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs font-bold text-[#1c1917]">
                        Anexar Comprovante do PIX
                      </p>
                      <p className="text-[11px] text-[#786e64]">
                        Tire uma foto ou selecione o print do seu banco (JPG, PNG)
                      </p>
                    </div>
                    <button
                      type="button"
                      className="mt-1 px-4 py-2 bg-[#1c1917] text-white rounded-lg text-xs font-semibold tracking-wide hover:bg-[#322c29] transition-colors flex items-center gap-1.5 shadow-sm"
                    >
                      <Upload className="w-3.5 h-3.5 text-[#e6c687]" />
                      Escolher Comprovante
                    </button>
                  </div>
                ) : (
                  <div className="bg-white p-3 rounded-xl border border-emerald-200 flex items-center justify-between gap-3 shadow-xs">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        onClick={() => setShowReceiptZoom(true)}
                        className="relative cursor-pointer group shrink-0"
                        title="Clique para ampliar"
                      >
                        <img
                          src={receiptPreview}
                          alt="Comprovante do PIX"
                          className="w-12 h-16 object-cover rounded-lg border border-emerald-300 bg-stone-100 group-hover:opacity-85 transition-opacity"
                        />
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 rounded-lg flex items-center justify-center transition-opacity">
                          <Eye className="w-3.5 h-3.5 text-white" />
                        </div>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1 text-emerald-800 font-bold text-xs">
                          <Check className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">Comprovante Anexado!</span>
                        </div>
                        <p className="text-[10px] text-[#786e64] truncate mt-0.5 max-w-[170px]">
                          {receiptFileName || 'comprovante-pix.jpg'}
                        </p>
                        <span className="text-[9px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 mt-1 inline-block">
                          Pronto para enviar no WhatsApp
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5 shrink-0 text-right">
                      <button
                        type="button"
                        onClick={() => receiptInputRef.current?.click()}
                        className="text-[11px] text-[#8e6e34] hover:text-[#5c441c] hover:underline font-semibold"
                      >
                        Trocar foto
                      </button>
                      <button
                        type="button"
                        onClick={handleRemoveReceipt}
                        className="text-[11px] text-rose-600 hover:text-rose-800 hover:underline font-medium"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                )}

                {isProcessingReceipt && (
                  <div className="flex items-center gap-2 text-xs text-[#8e6e34] justify-center py-1">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Otimizando imagem do comprovante...</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Footer & Checkout Action */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 bg-white border-t border-[#e8dfd2] space-y-3">
              <div className="space-y-1 text-xs text-[#5c544c]">
                <div className="flex justify-between">
                  <span>Subtotal das Peças:</span>
                  <span className="font-semibold text-[#1c1917]">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Forma de Pagamento:</span>
                  <span className="font-semibold text-emerald-800">PIX à Vista</span>
                </div>
                <div className="flex justify-between items-baseline pt-2 border-t border-[#f0ebe3]">
                  <span className="font-serif text-sm font-bold text-[#1c1917]">Total a Pagar:</span>
                  <span className="font-serif text-xl font-bold text-[#1c1917]">
                    {formatCurrency(subtotal)}
                  </span>
                </div>
              </div>

              {/* Notice if receipt not yet attached */}
              {!receiptPreview && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg flex items-center gap-2 text-amber-900 text-[11px]">
                  <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
                  <span>
                    <strong>Obrigatório:</strong> Anexe o comprovante do PIX acima para liberar o envio do pedido no WhatsApp.
                  </span>
                </div>
              )}

              <button
                type="button"
                id="cart-submit-order-whatsapp-button"
                onClick={handleCheckout}
                disabled={isSubmittingOrder}
                className={`w-full py-3.5 px-5 rounded-xl text-xs uppercase tracking-[0.15em] font-semibold transition-all shadow-md flex items-center justify-center gap-2 ${
                  !receiptPreview
                    ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer'
                    : 'bg-[#1b803a] hover:bg-[#156e31] text-white'
                }`}
              >
                {isSubmittingOrder ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    Processando Pedido...
                  </>
                ) : !receiptPreview ? (
                  <>
                    <Upload className="w-4 h-4" />
                    Anexar Comprovante PIX para Finalizar
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Finalizar Pedido no WhatsApp (Comprovante Anexado)
                  </>
                )}
              </button>

              <p className="text-[10px] text-center text-[#8c8278] leading-tight">
                {receiptPreview
                  ? 'Seu pedido será registrado e você será direcionada para o WhatsApp da Mariane com o comprovante anexado!'
                  : 'Para finalizar, anexe o comprovante do PIX. O pedido será registrado no painel e enviado para a Mariane no WhatsApp.'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Full-size Receipt Zoom Modal */}
      {showReceiptZoom && receiptPreview && (
        <div
          className="fixed inset-0 z-[80] bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
          onClick={() => setShowReceiptZoom(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-hidden flex flex-col p-4 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800">
                Visualização do Comprovante PIX
              </h4>
              <button
                type="button"
                onClick={() => setShowReceiptZoom(false)}
                className="p-1 rounded-full text-stone-500 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-auto max-h-[75vh] flex justify-center bg-stone-50 p-2 rounded-lg border">
              <img
                src={receiptPreview}
                alt="Comprovante Ampliado"
                className="max-h-[70vh] object-contain rounded"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
