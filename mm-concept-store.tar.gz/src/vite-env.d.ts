/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANON_KEY?: string;
  readonly VITE_STORE_WHATSAPP?: string;
  readonly VITE_STORE_PIX_KEY?: string;
  readonly VITE_STORE_PIX_NAME?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
